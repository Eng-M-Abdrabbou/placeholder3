# Currency > 2025-05-18 1:31am
https://universe.roboflow.com/mahmouds/currency-vzh7u

Provided by a Roboflow user
License: MIT

